package com.example.terencechu_comp304lab2_ex1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.RadioButton
import android.widget.RadioGroup

class CheckoutPaymentOptions : AppCompatActivity() {
    lateinit var selectedUnit : String
    lateinit var selectedPaymentOption : String
    lateinit var next_activity_intent : Intent

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkout_payment_options)

        supportActionBar?.setTitle("Select payment option")

        val bundle = intent.extras
        selectedUnit = bundle?.getString("selectedUnit").toString()

        // System.out.println(selectedUnit)

        val radioGroup : RadioGroup = findViewById(R.id.rg_payment)

        radioGroup.setOnCheckedChangeListener { group, checkedId ->
            val rbPaymentCash : RadioButton = findViewById(R.id.rb_payment_cash)
            val rbPaymentCredit : RadioButton = findViewById(R.id.rb_payment_credit)
            val rbPaymentDebit : RadioButton = findViewById(R.id.rb_payment_debit)

            if (rbPaymentCash.isChecked) {
                selectedPaymentOption = rbPaymentCash.text.toString()
            } else if (rbPaymentCredit.isChecked) {
                selectedPaymentOption = rbPaymentCredit.text.toString()
            } else if (rbPaymentDebit.isChecked) {
                selectedPaymentOption = rbPaymentDebit.text.toString()
            }

            // System.out.println(selectedPaymentOption)

        }
    }

    fun clickCheckout(view: View) {
        var isCash : Boolean = false

        // System.out.println(selectedPaymentOption)

        if (selectedPaymentOption == "Cash") {
            next_activity_intent = Intent(this, Success::class.java)
            isCash = true
        } else {
            next_activity_intent = Intent(this, CheckoutCardDetails::class.java)
        }

        val bundle = Bundle()
        bundle.putString("selectedUnit", selectedUnit)
        bundle.putString("selectedPaymentOption", selectedPaymentOption)
        bundle.putBoolean("isCash", isCash)
        next_activity_intent.putExtras(bundle)
        startActivity(next_activity_intent)
    }
}