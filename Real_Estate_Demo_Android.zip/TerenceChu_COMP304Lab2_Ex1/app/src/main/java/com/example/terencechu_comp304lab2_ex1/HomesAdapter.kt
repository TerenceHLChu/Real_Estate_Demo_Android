package com.example.terencechu_comp304lab2_ex1

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

// Create a custom adapter class that extends RecyclerView.Adapter
class HomesAdapter
    (private val context: Context, private var detailsList: List<String>, private var picList: List<String>)
    : RecyclerView.Adapter<HomesAdapter.MyViewHolder>(){

    val checkedPositions = mutableSetOf<Int>()

    // Per Android for Developers documentation: The ViewHolder is a wrapper around a View that
    // contains the layout for an individual item in the list. The Adapter creates ViewHolder
    // objects as needed and also sets the data for those views.
    // Source: https://developer.android.com/develop/ui/views/layout/recyclerview
    inner class MyViewHolder (view: View) : RecyclerView.ViewHolder(view){
        var homeDetails : TextView = view.findViewById(R.id.tv_home_details)
        var homePic: ImageView = view.findViewById(R.id.iv_home_pic)
        var chkHome : CheckBox = view.findViewById(R.id.chk_home)

        init {
            chkHome.setOnCheckedChangeListener { buttonView, isChecked ->
                val position = adapterPosition
                if (isChecked) {
                    checkedPositions.add(position)
                } else {
                    checkedPositions.remove(position)
                }
//                }
            }
        }
    }

    // Create (inflate) a new ViewHolder and return it
    // Does not populate (bind) ViewHolder with a View (that will happen next)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val homeView = LayoutInflater.from(parent.context)
            .inflate(R.layout.home_view, parent, false)
        return MyViewHolder(homeView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val details = detailsList[position]
        val pic = picList[position]
        val imageResourceId = context.resources.getIdentifier(pic, "drawable", context.packageName)
        // System.out.println(imageResourceId)
        // System.out.println(pic)
        // System.out.println(checkedPositions)
        holder.homeDetails.text = details
        holder.homePic.setImageResource(imageResourceId)
    }

    override fun getItemCount(): Int {
        return detailsList.size
    }

    fun getPositionOfCheckedUnits(): Set<Int> {
        return checkedPositions
    }

}