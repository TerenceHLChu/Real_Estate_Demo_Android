// Student name: Terence Chu
// Student number: 301220117

package com.example.terencechu_comp304lab2_ex1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.setTitle("LeaseOrRentHome Inc.")
    }

    fun clickEnter(view: View) {
        val intent = Intent(this, HomeTypeSelection::class.java)
        startActivity(intent)
    }

}