package com.example.terencechu_comp304lab2_ex1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class Success : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_success)

        supportActionBar?.setTitle("Success!")

        val bundle = intent.extras
        val selectedUnit = bundle?.getString("selectedUnit")
        val selectedPaymentOption = bundle?.getString("selectedPaymentOption")
        val isCash = bundle?.getBoolean("isCash")
        val tvSuccess : TextView = findViewById(R.id.tv_success)

        // System.out.println(selectedUnit)
        // System.out.println(selectedPaymentOption)
        // System.out.println(isCash)

        if(isCash == true) {
            tvSuccess.text = "Thank you for your ${selectedPaymentOption} payment!\n\n" +
                    "Ordered:\n ${selectedUnit}"
        } else {
            val cardHolderName = bundle?.getString("cardHolderName")
            val sport = bundle?.getString("sport")
            val food = bundle?.getString("food")
            val season = bundle?.getString("season")

            // System.out.println(cardHolderName)
            // System.out.println(sport)
            // System.out.println(food)
            // System.out.println(season)

            tvSuccess.text = "Thank you ${cardHolderName} for your ${selectedPaymentOption} payment!\n\n" +
                    "Ordered:\n ${selectedUnit}\n\n" +
                    "Favourite sport: ${sport} \n" +
                    "Favourite food: ${food} \n" +
                    "Favourite season: ${season}"

        }

    }
}
