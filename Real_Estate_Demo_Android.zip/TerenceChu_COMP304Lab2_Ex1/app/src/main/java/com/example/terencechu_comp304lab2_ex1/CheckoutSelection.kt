package com.example.terencechu_comp304lab2_ex1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.RadioButton
import android.widget.RadioGroup

class CheckoutSelection : AppCompatActivity() {
    lateinit var selectedRadioButton : RadioButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkout_selection)

        supportActionBar?.setTitle("Select Unit for Checkout")

        val bundle = intent.extras
        val detailsList = bundle?.getStringArrayList("detailsList")

        var numberOfRadioButtons = detailsList?.size

        // Dynamically create radio buttons (depends on number of homes user wants to see)
        // Based on the following tutorial: https://www.geeksforgeeks.org/dynamic-radiobutton-in-kotlin/
        val rgCheckoutSelection : RadioGroup = findViewById(R.id.rg_checkout_selection)

        for (i in 0 until numberOfRadioButtons!!) {
            val radioButton = RadioButton(this)
            radioButton.text = detailsList?.get(i)
            radioButton.setTextSize(TypedValue.COMPLEX_UNIT_SP,20F)
            // System.out.println(detailsList?.get(i))
            rgCheckoutSelection.addView(radioButton)
        }

        rgCheckoutSelection.setOnCheckedChangeListener { group, checkedId ->
            selectedRadioButton = findViewById(checkedId)
        }

        // System.out.println(detailsList)
        // System.out.println(numberOfRadioButtons)
    }

    fun clickCheckout(view: View) {
        val selectedUnitForCheckout = selectedRadioButton.text
        val intent = Intent(this, CheckoutPaymentOptions::class.java)
        val bundle = Bundle()
        bundle.putString("selectedUnit", selectedUnitForCheckout.toString())
        intent.putExtras(bundle)
        startActivity(intent)
    }
}