package com.example.terencechu_comp304lab2_ex1
//
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity

//
class HomeTypeSelection : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_type_selection)
        supportActionBar?.setTitle("Choose Home Type")
    }

    // Inflate options menu
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.menu, menu)
        return true
    }

    // Move to another activity once an option is chosen
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_apartment -> {
                val intent = Intent(this, Apartments::class.java)
                startActivity(intent)
            true}
            R.id.menu_detached -> {
                val intent = Intent(this, Detached::class.java)
                startActivity(intent)
                true}
            R.id.menu_semi_detached -> {
                val intent = Intent(this, SemiDetached::class.java)
                startActivity(intent)
                true}
            R.id.menu_condo -> {
                val intent = Intent(this, Condo::class.java)
                startActivity(intent)
                true}
            R.id.menu_town_house -> {
                val intent = Intent(this, TownHouse::class.java)
                startActivity(intent)
                true}
        else -> super.onOptionsItemSelected(item)
        }
    }
}
