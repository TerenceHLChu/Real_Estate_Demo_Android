package com.example.terencechu_comp304lab2_ex1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Detached : AppCompatActivity() {
    private val detailsList = ArrayList<String>()
    private val picList = ArrayList<String>()
    private lateinit var homesAdapter : HomesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detached)

        supportActionBar?.setTitle("Select Units to Visit")

        // Locate recycler view
        val apartmentRecyclerView : RecyclerView = findViewById(R.id.rv_homes)

        // Instantiate new instance with detailsList and picList
        homesAdapter = HomesAdapter(this, detailsList, picList)

        // Set the recycler view to a linear layout (for display of the list)
        val layoutManager = LinearLayoutManager(applicationContext)
        apartmentRecyclerView.layoutManager = layoutManager

        // Set the recycler view's adapter to retrieve the list
        apartmentRecyclerView.adapter = homesAdapter

        prepareLists()
    }

    private fun prepareLists() {
        detailsList.add("1 Detached St. \n$100")
        detailsList.add("2 Detached St. \n$200")
        detailsList.add("3 Detached St. \n$300")
        detailsList.add("4 Detached St. \n$400")
        picList.add("detached_1")
        picList.add("detached_2")
        picList.add("detached_3")
        picList.add("detached_4")

    }

    fun clickDetachedVisit(view: View) {
        val checkedUnits = homesAdapter.getPositionOfCheckedUnits() // Get indices of units that the checkbox was checked
        val detailsListForCheckout = ArrayList<String>()

        // System.out.println(checkedUnits)

        for (i in checkedUnits) {
            // System.out.println(i)
            detailsListForCheckout.add(detailsList[i])
        }

        // System.out.println(detailsListForCheckout)

        val intent = Intent(this, CheckoutSelection::class.java)
        val bundle = Bundle()
        bundle.putStringArrayList("detailsList", detailsListForCheckout)
        intent.putExtras(bundle)
        startActivity(intent)
    }
}

// Images attribution: Image By freepik (https://www.freepik.com/free-photo/luxury-house-real-estate-sale-property-generative-ai_39657463.htm#query=detached%20home%20artist%20rendtition&position=7&from_view=search&track=ais&uuid=af2205ac-cb70-4f36-8873-fc901594da4f)