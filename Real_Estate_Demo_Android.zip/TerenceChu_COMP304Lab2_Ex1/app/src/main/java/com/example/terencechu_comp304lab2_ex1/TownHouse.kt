package com.example.terencechu_comp304lab2_ex1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class TownHouse : AppCompatActivity() {
    private val detailsList = ArrayList<String>()
    private val picList = ArrayList<String>()
    private lateinit var homesAdapter : HomesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_town_house)

        supportActionBar?.setTitle("Select Units to Visit")

        // Locate recycler view
        val apartmentRecyclerView : RecyclerView = findViewById(R.id.rv_homes)

        // Instantiate new instance with detailsList and picList
        homesAdapter = HomesAdapter(this, detailsList, picList)

        // Set the recycler view to a linear layout (for display of the list)
        val layoutManager = LinearLayoutManager(applicationContext)
        apartmentRecyclerView.layoutManager = layoutManager

        // Set the recycler view's adapter to retrieve the list
        apartmentRecyclerView.adapter = homesAdapter

        prepareLists()
    }

    private fun prepareLists() {
        detailsList.add("1 Town House St. \n$100")
        detailsList.add("2 Town House St. \n$200")
        detailsList.add("3 Town House St. \n$300")
        detailsList.add("4 Town House St. \n$400")
        picList.add("town_house_1")
        picList.add("town_house_2")
        picList.add("town_house_3")
        picList.add("town_house_4")
    }

    fun clickTownHouseVisit(view: View) {
        val checkedUnits = homesAdapter.getPositionOfCheckedUnits() // Get indices of units that the checkbox was checked
        val detailsListForCheckout = ArrayList<String>()

        // System.out.println(checkedUnits)

        for (i in checkedUnits) {
            // System.out.println(i)
            detailsListForCheckout.add(detailsList[i])
        }

        //  System.out.println(detailsListForCheckout)

        val intent = Intent(this, CheckoutSelection::class.java)
        val bundle = Bundle()
        bundle.putStringArrayList("detailsList", detailsListForCheckout)
        intent.putExtras(bundle)
        startActivity(intent)
    }
}

// Images attribution: Image By pexels (https://www.pexels.com/photo/house-lights-turned-on-106399/)