package com.example.terencechu_comp304lab2_ex1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Condo : AppCompatActivity() {
    private val detailsList = ArrayList<String>()
    private val picList = ArrayList<String>()
    private lateinit var homesAdapter : HomesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_condo)

        supportActionBar?.setTitle("Select Units to Visit")

        // Locate recycler view
        val apartmentRecyclerView : RecyclerView = findViewById(R.id.rv_homes)

        // Instantiate new instance with detailsList and picList
        homesAdapter = HomesAdapter(this, detailsList, picList)

        // Set the recycler view to a linear layout (for display of the list)
        val layoutManager = LinearLayoutManager(applicationContext)
        apartmentRecyclerView.layoutManager = layoutManager

        // Set the recycler view's adapter to retrieve the list
        apartmentRecyclerView.adapter = homesAdapter

        prepareLists()
    }

    private fun prepareLists() {
        detailsList.add("1 Condo St. \n$100")
        detailsList.add("2 Condo St. \n$200")
        detailsList.add("3 Condo St. \n$300")
        detailsList.add("4 Condo St. \n$400")
        picList.add("condo_1")
        picList.add("condo_2")
        picList.add("condo_3")
        picList.add("condo_4")

    }

    fun clickCondoVisit(view: View) {
        val checkedUnits = homesAdapter.getPositionOfCheckedUnits() // Get indices of units that the checkbox was checked
        val detailsListForCheckout = ArrayList<String>()

        // System.out.println(checkedUnits)

        for (i in checkedUnits) {
            // System.out.println(i)
            detailsListForCheckout.add(detailsList[i])
        }

        // System.out.println(detailsListForCheckout)

        val intent = Intent(this, CheckoutSelection::class.java)
        val bundle = Bundle()
        bundle.putStringArrayList("detailsList", detailsListForCheckout)
        intent.putExtras(bundle)
        startActivity(intent)
    }
}

// Images attribution: Image By freepik (https://www.freepik.com/free-photo/vertical-shot-white-building-clear-sky_8281219.htm#query=condo&position=10&from_view=search&track=sph&uuid=a9f8fd0a-d89f-4715-962f-e6fcb2b9f13d)