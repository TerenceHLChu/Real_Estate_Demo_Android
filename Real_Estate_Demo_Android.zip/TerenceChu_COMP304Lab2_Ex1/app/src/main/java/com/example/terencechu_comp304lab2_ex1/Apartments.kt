package com.example.terencechu_comp304lab2_ex1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Apartments : AppCompatActivity() {
    private val detailsList = ArrayList<String>()
    private val picList = ArrayList<String>()
    private lateinit var homesAdapter : HomesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apartments)

        supportActionBar?.setTitle("Select Units to Visit")

        // Locate recycler view
        val apartmentRecyclerView : RecyclerView = findViewById(R.id.rv_homes)

        // Instantiate new instance with detailsList and picList
        homesAdapter = HomesAdapter(this, detailsList, picList)

        // Set the recycler view to a linear layout (for display of the list)
        val layoutManager = LinearLayoutManager(applicationContext)
        apartmentRecyclerView.layoutManager = layoutManager

        // Set the recycler view's adapter to retrieve the list
        apartmentRecyclerView.adapter = homesAdapter

        prepareLists()
    }

    private fun prepareLists() {
        detailsList.add("123 Fake St. \n$100")
        detailsList.add("123 Not Fake Rd. \n$200")
        detailsList.add("13579 Main Cres. \n$300")
        detailsList.add("2468 Some St. \n$400")
        detailsList.add("1 A Blvd. \n$500")
        detailsList.add("2 B Blvd. \n$600")
        picList.add("apartment_1")
        picList.add("apartment_2")
        picList.add("apartment_3")
        picList.add("apartment_4")
        picList.add("apartment_5")
        picList.add("apartment_6")
    }

    fun clickApartmentVisit(view: View) {
        val checkedUnits = homesAdapter.getPositionOfCheckedUnits() // Get indices of units that the checkbox was checked

        val detailsListForCheckout = ArrayList<String>()

        // System.out.println(checkedUnits)

        for (i in checkedUnits) {
            // System.out.println(i)
            detailsListForCheckout.add(detailsList[i])
        }

        // System.out.println(detailsListForCheckout)

        val intent = Intent(this, CheckoutSelection::class.java)
        val bundle = Bundle()
        bundle.putStringArrayList("detailsList", detailsListForCheckout)
        intent.putExtras(bundle)
        startActivity(intent)
    }
}

// Images attribution: Image By freepik (https://www.freepik.com/free-ai-image/3d-rendering-house-model_66612096.htm#query=apartment&position=0&from_view=search&track=sph&uuid=18d5f555-d44e-4806-bdc9-63b568c85ef5)