package com.example.terencechu_comp304lab2_ex1

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.core.widget.addTextChangedListener
import java.util.Calendar

class CheckoutCardDetails : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkout_card_details)

        supportActionBar?.setTitle("Credit/debit card details")
    }

    fun clickCheckout(view: View) {
        val bundle = intent.extras
        val selectedUnit = bundle?.getString("selectedUnit")
        val selectedPaymentOption = bundle?.getString("selectedPaymentOption")
        val isCash = bundle?.getBoolean("isCash")

        // System.out.println(selectedUnit)
        // System.out.println(selectedPaymentOption)
        // System.out.println(isCash)

        val expirationYear : EditText = findViewById(R.id.txt_year)
        val expirationMonth : EditText = findViewById(R.id.txt_month)

        val calendar = Calendar.getInstance()
        val currentYear = calendar.get(Calendar.YEAR)
        val currentMonth = calendar.get(Calendar.MONTH) + 1 // Calendar.MONTH is zero based

        val finalIntent = Intent(this, Success::class.java)
        val finalBundle = Bundle()
        val cardHolderName : EditText = findViewById(R.id.txt_name)
        val sport : EditText = findViewById(R.id.txt_sport)
        val food : EditText = findViewById(R.id.txt_food)
        val season : EditText = findViewById(R.id.txt_season)

        // System.out.println(currentYear)
        // System.out.println(currentMonth)
        // System.out.println(expirationYear.text.toString().toInt())
        // System.out.println(expirationMonth.text.toString().toInt())

        if (expirationYear.text.toString().toInt() < currentYear) {
            Toast.makeText(this, "Expiration date must not be earlier than current month and year", Toast.LENGTH_SHORT).show()
        } else if (expirationYear.text.toString().toInt() == currentYear) {
            if (expirationMonth.text.toString().toInt() < currentMonth) {
                Toast.makeText(this, "Expiration date must not be earlier than current month and year", Toast.LENGTH_SHORT).show()
            }
        } else {
            finalBundle.putString("selectedUnit", selectedUnit)
            finalBundle.putString("selectedPaymentOption", selectedPaymentOption)
            if (isCash != null) {
                finalBundle.putBoolean("isCash", isCash)
            finalBundle.putString("cardHolderName", cardHolderName.text.toString())
            finalBundle.putString("sport", sport.text.toString())
            finalBundle.putString("food", food.text.toString())
            finalBundle.putString("season", season.text.toString())
            finalIntent.putExtras(finalBundle)
            startActivity(finalIntent)
            }
        }


    }
}